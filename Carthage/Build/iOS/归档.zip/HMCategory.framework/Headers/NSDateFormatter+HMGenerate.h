//  NSDateFormatter+HMGenerate.h
//  Created on 2018/11/27
//  Description <#文件描述#>

//  Copyright © 2018 Huami inc. All rights reserved.
//  @author zhanggui(zhanggui@huami.com)

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDateFormatter (HMGenerate)

+ (instancetype)formatter;

@end

NS_ASSUME_NONNULL_END

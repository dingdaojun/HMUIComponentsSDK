//
//  UIView+Subviews.h
//  MiFit
//
//  Created by dingdaojun on 15/11/27.
//  Copyright © 2015年 Anhui Huami Information Technology Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Subviews)

- (void)hm_removeAllSubviews;
- (void)hm_addSingleSubview:(UIView *)subview;

@end

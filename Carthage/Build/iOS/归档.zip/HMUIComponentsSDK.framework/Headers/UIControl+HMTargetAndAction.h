//
//  UIControl+HMTargetAndAction.h
//  MiDongTrainingCenter
//
//  Created by dingdaojun on 2017/11/28.
//  Copyright © 2017年 Anhui Huami Information Technology Co., Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface UIControl (HMTargetAndAction)

- (void)hmRemoveAllTargetsAndActions;

@end
